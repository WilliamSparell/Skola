﻿namespace WS_Genealogi
{
    using WS_Genealogi.Menu;
    class Program
    {
        static void Main()
        {
            MainMenu mainMenu = new MainMenu();
            mainMenu.StartMenu();
        }
    }
}
